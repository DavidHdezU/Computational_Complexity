# Instrucciones para ejecutar el Programa 01

En esta práctica se encuentran 2 archivos .py,

## Para ejecutar el programa de Alcanzabilidad, se debe correr el siguiente comando en la terminal
```
python3 Alcanzabilidad.py
```

## Para ejecutar el programa de 3-SAT, se debe correr el siguiente comando en la terminal

```
python3 3-SAT.py
```
