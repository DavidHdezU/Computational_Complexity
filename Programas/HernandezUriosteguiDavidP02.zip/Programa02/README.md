# Instrucciones para ejecutar el Programa 03

En esta práctica se encuentra el archivo SubSetSum.py,

## Para ejecutar el programa de SubSetSum, se debe correr el siguiente comando en la terminal
```
python3 SubSetSum.py
```

